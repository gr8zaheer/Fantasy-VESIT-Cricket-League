$(document).ready(
	function()
	{
		$('.loader').load('homepage.php');

		$('ul#options li a').click(function(){
			var link = $(this).attr('href');
			$('.loader').load(link+'.php'); 
			return false;
		});
	}
);

function wait()
{
	bootbox.dialog({
		size:'small',
		message:'<h3 style="text-align:center;padding:30px;">Please Wait...</h3>'
	});
}

function show()
{
	var cat = $('#category').val();
	var datastring = 'cat='+cat;
	$.ajax({
		type : 'post',
		url : 'd_getplayers.php',
		data : datastring,
		cache:false,
		success : function(msg){
			$('#display').html(msg);
		}
	});
	return false;
}

function showDetails()
{
	$.ajax({
		type : 'post',
		url : 'd_getdetails.php',
		cache:false,
		success : function(msg){
			$('.money-players').html(msg);
		}
	});
	return false;
}

function showNumber()
{
	$.ajax({
		type : 'post',
		url : 'd_getnumber.php',
		cache:false,
		success : function(msg){
			$('.number-players').html(msg);
		}
	});
	return false;
}

function showSquad()
{
	$.ajax({
		type : 'post',
		url : 'd_getsquad.php',
		cache:false,
		success : function(msg){
			$('.squad-players').html(msg);
		}
	});
	return false;
}

function showTeam()
{
	$.ajax({
		type : 'post',
		url : 'd_getteamlist.php',
		cache:false,
		success : function(msg){
			$('.team_subs').html(msg);
		}
	});
	return false;
}

function showTeamDetails()
{
	$.ajax({
		type : 'post',
		url : 'd_getteamdetails.php',
		cache:false,
		success : function(msg){
			$('.team_info').html(msg);
		}
	});
	return false;
}

function showTransferList()
{
	$.ajax({
		type : 'post',
		url : 'd_gettransfers.php',
		cache:false,
		success : function(msg){
			$('#transfer_display').html(msg);
		}
	});
	return false;
}

function clicked()
{
	bootbox.dialog({
		size:'small',
		message:'<h3 style="text-align:center;padding:20px;">Player Added Successfully<br><span class="fa fa-check-circle fa-2x" style="color:green;"></span></h3>'
	});
}

function failed()
{
	bootbox.dialog({
		size:'small',
		message:'<h3 style="text-align:center;"><span class="fa fa-times" style="color:red;"></span>&nbsp;Not Enough Balance</p>'
	});
}

function removed()
{
	bootbox.dialog({
		size:'small',
		message:'<h3 style="text-align:center;padding:30px;">Player Removed<br><span class="fa fa-trash fa-2x" style="color:#a6a6a6;"></span></p>'
	});
}

function oops()
{
	bootbox.dialog({
		size:'small',
		message:'<h3 style="text-align:center;padding:30px;"><span class="fa fa-trash" style="color:red;"></span>&nbsp;Player Removed</p>'
	});
}

function Exceeded()
{
	bootbox.dialog({
		size:'small',
		message:'<h4 style="text-align:center;padding:30px;"><i class="fa fa-exclamation-triangle" style="color:#e6e600;" aria-hidden="true"></i><br>Maximum number of players for this position selected</h4>'
	});
}

function openteam()
{
	$('.loader').load('d_getteam.php');
}

function info(id)
{
	var datastring = 'id='+id;
	$.ajax({
		type:'POST',
		url:'f_getinfo.php',
		data:datastring,
		beforeSend:function(){
			bootbox.dialog({
				message:'<h3 class="text-center">Please wait...</h3>',
				closeButton:'false'
			});
		},
		success:function(msg){
			bootbox.alert({
			message:''+msg+'',
			size:'small'
			});
		}
	});
}

function swap(swap_id)
{
	var datastring = 'swap_id='+swap_id; 
	$.ajax({
		type:'POST',
		url:'f_swap.php',
		data:datastring,
		beforeSend:function(){
			bootbox.dialog({
				message:'<h3 class="text-center">Please wait...</h3>',
				closeButton:'false'
			});
		},
		success:function(msg)
		{
			var feedback = String(msg);
			if(feedback == 'success')
			{
				bootbox.hideAll();
				bootbox.alert({
					message:'<h3 class="text-center">Substitution successful<br><i class="fa fa-check" aria-hidden="true" style="color:green;3"></i></h3>',
					size:'small'
				});
				showTeamDetails();
				showTeam();
			}
			else
			{
				alert(msg);
			}
		}
	});
}

function transfer_swap(swap_id)
{
	var datastring = 'swap_id='+swap_id; 
	$.ajax({
		type:'POST',
		url:'f_transferswap.php',
		data:datastring,
		beforeSend:function()
		{
			wait();
		},
		success:function(msg)
		{
			var feedback = String(msg);
			if(feedback == 'success')
			{
				bootbox.hideAll();
				bootbox.alert({
					message:'<h3 class="text-center">Transfer successful<br><i class="fa fa-check" aria-hidden="true" style="color:green;3"></i></h3>',
					size:'small'
				});
				showTeamDetails();
				showTeam();
				showTransferList();
			}
			else if(feedback == 'not enough balance')
			{
				failed();
			}
			else
			{
				bootbox.alert({
					message:msg
				});
			}
		}
	});
}

function cap(id)
{
	var datastring = 'id='+id; 
	$.ajax({
		type:'POST',
		url:'f_cap.php',
		data:datastring,
		beforeSend:function()
		{
			wait();
		},
		success:function(msg)
		{
			var feedback = String(msg);
			if(feedback == 'success')
			{
				bootbox.hideAll();
				bootbox.alert({
					message:'<h3 class="text-center">Captain Changed<br><i class="fa fa-check" aria-hidden="true" style="color:green;3"></i></h3>',
					size:'small'
				});
				showTeamDetails();
				showTeam();
				showTransferList();
			}
			else
			{
				alert(msg);
			}
		}
	});
}



	

	
	