if($(window).width() > 992)
	{	
				$('table#trans_table').css("width","100%");
				$('table#trans_table').css("font-size","12px");
	}
	else if($(window).width() < 768)
	{
				$('table#trans_table').css("font-size","10px");
				$('table#trans_table').css("width","100%");
	}
	else
	{
				$('table#trans_table').css("width","100%");
				$('table#trans_table').css("font-size","12px");
	}

	$(window).resize(function(){
		if($(window).width() > 992)
			{	
				$('table#trans_table').css("width","100%");
				$('table#trans_table').css("font-size","12px");
			}
		else if($(window).width() < 768)
			{
				$('table#trans_table').css("font-size","10px");
				$('table#trans_table').css("width","100%");
			}
		else
			{
				$('table#trans_table').css("width","100%");
				$('table#trans_table').css("font-size","12px");
			}
	});


function info2(id)
{
	var datastring = 'id='+id;
	$.ajax({
		type:'POST',
		url:'f_getinfo.php',
		data:datastring,
		beforeSend:function(){
			bootbox.dialog({
				message:'<h3 class="text-center">Please wait...</h3>',
				closeButton:'false'
			});
		},
		success:function(msg){
			bootbox.alert({
			message:''+msg+'',
			size:'small'
			});
		}
	});
	return false;
}

function transfer(id)
{
	var datastring = 'id='+id;
	$.ajax({
		type:'POST',
		url:'f_gettrans.php',
		data:datastring,
		beforeSend:function(){
			bootbox.dialog({
				message:'<h3 class="text-center">Please wait...</h3>',
				closeButton:'false'
			});
		},
		success:function(msg){
			bootbox.dialog({
				message:msg,
			});
		}
	});
	return false;
}